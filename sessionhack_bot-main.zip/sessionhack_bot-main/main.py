import os
os.system("git clone https://github.com/LEGENDXOP/sessionhack_bot")
os.system("cd sessionhack_bot && python bot.py")
